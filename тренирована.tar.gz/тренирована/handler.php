<?php
/* Здесь проверяется существование переменных */
if (isset($_POST['serg.milkov73@mail.ru'])) {$phone = $_POST['serg.milkov73@mail.ru'];}
// if (isset($_POST['phone'])) {$name = $_POST['phone'];}
if (isset($_POST['serg.milkov73@mail.ru'])) {$name = $_POST['serg.milkov73@mail.ru'];}
 
/* Сюда впишите свою эл. почту */
$myaddres  = "serg.milkov73@mail.ru"; // кому отправляем
 
/* А здесь прописывается текст сообщения, \n - перенос строки */
$mes = "Тема: Заказ обратного звонка!\nТелефон: $phone\nИмя: $name";
 
/* А эта функция как раз занимается отправкой письма на указанный вами email */
$sub='Заказ'; //сабж
$email='Заказ обратного звонка'; // от кого
$send = mail ($myaddres,$sub,$mes,"Content-type:text/plain; charset = utf-8\r\nFrom:$email");
 
ini_set('short_open_tag', 'On');
header('Refresh: 3; URL=index.html');
?>
